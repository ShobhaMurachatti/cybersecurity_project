import argparse
import itertools
import random
import string
from datetime import datetime
import zxcvbn
import nltk
from nltk.corpus import words
import tkinter as tk
from tkinter import messagebox, filedialog, ttk

# Download NLTK words if not already done
try:
    nltk.data.find('corpora/words')
except LookupError:
    nltk.download('words')

# Leetspeak mappings
LEET_MAP = {
    'a': ['4', '@'],
    'b': ['8'],
    'e': ['3'],
    'g': ['9'],
    'i': ['1', '!'],
    'l': ['1'],
    'o': ['0'],
    's': ['5', '$'],
    't': ['7'],
    'z': ['2']
}

def generate_leetspeak(word):
    """Generate leetspeak variations of a word."""
    variations = [word]
    for char, replacements in LEET_MAP.items():
        new_variations = []
        for var in variations:
            for rep in replacements:
                new_variations.append(var.replace(char, rep))
        variations.extend(new_variations)
    return list(set(variations))  # Remove duplicates

def generate_years(start=1900, end=2030):
    """Generate a list of years."""
    return [str(year) for year in range(start, end + 1)]

def generate_wordlist(name, date, pet, include_leet=True, include_years=True, max_combinations=10000):
    """Generate a custom wordlist based on inputs."""
    base_words = []
    if name:
        base_words.append(name.lower())
        # Add synonyms or related words using NLTK (simple example)
        try:
            synonyms = [w for w in words.words() if w.startswith(name.lower()[:3]) and len(w) > 3][:5]  # Limit to 5
            base_words.extend(synonyms)
        except:
            pass
    if pet:
        base_words.append(pet.lower())
    if date:
        try:
            dt = datetime.strptime(date, '%Y-%m-%d')
            base_words.extend([str(dt.year), str(dt.month).zfill(2), str(dt.day).zfill(2)])
        except ValueError:
            pass  # Invalid date, skip

    # Add some common words from NLTK
    common_words = random.sample([w for w in words.words() if len(w) > 3][:100], 10)  # Random 10 common words
    base_words.extend(common_words)

    # Generate combinations
    combinations = set()
    for r in range(1, min(len(base_words), 4) + 1):  # Limit permutations to avoid explosion
        for combo in itertools.permutations(base_words, r):
            word = ''.join(combo)
            combinations.add(word)
            if include_leet:
                combinations.update(generate_leetspeak(word))
            if include_years:
                years = generate_years()
                for year in years:
                    combinations.add(word + year)
                    combinations.add(year + word)
                    if include_leet:
                        leet_word = random.choice(generate_leetspeak(word)) if generate_leetspeak(word) else word
                        combinations.add(leet_word + year)
                        combinations.add(year + leet_word)

    # Limit to max_combinations
    wordlist = list(combinations)[:max_combinations]
    random.shuffle(wordlist)
    return wordlist

def analyze_password(password):
    """Analyze password strength using zxcvbn."""
    result = zxcvbn.zxcvbn(password)
    return {
        'score': result['score'],  # 0-4
        'crack_time': result['crack_times_display']['offline_slow_hashing_1e4_per_second'],
        'feedback': result['feedback']['suggestions']
    }

def export_wordlist(wordlist, filename):
    """Export wordlist to a .txt file."""
    with open(filename, 'w') as f:
        for word in wordlist:
            f.write(word + '\n')
    print(f"Wordlist exported to {filename}")

def main():
    parser = argparse.ArgumentParser(description="Password Strength Analyzer and Custom Wordlist Generator")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Analyze command
    analyze_parser = subparsers.add_parser('analyze', help='Analyze password strength')
    analyze_parser.add_argument('password', help='Password to analyze')

    # Generate command
    generate_parser = subparsers.add_parser('generate', help='Generate custom wordlist')
    generate_parser.add_argument('--name', help='User name')
    generate_parser.add_argument('--date', help='Birth date in YYYY-MM-DD format')
    generate_parser.add_argument('--pet', help='Pet name')
    generate_parser.add_argument('--output', default='wordlist.txt', help='Output file name')
    generate_parser.add_argument('--no-leet', action='store_true', help='Disable leetspeak variations')
    generate_parser.add_argument('--no-years', action='store_true', help='Disable year appending')

    args = parser.parse_args()

    if args.command == 'analyze':
        result = analyze_password(args.password)
        print(f"Password Strength Score: {result['score']}/4")
        print(f"Estimated Crack Time: {result['crack_time']}")
        if result['feedback']:
            print("Suggestions:", ', '.join(result['feedback']))
        else:
            print("No suggestions.")

    elif args.command == 'generate':
        wordlist = generate_wordlist(
            args.name, args.date, args.pet,
            include_leet=not args.no_leet,
            include_years=not args.no_years
        )
        export_wordlist(wordlist, args.output)

    else:
        # If no args, launch GUI
        launch_gui()

def launch_gui():
    root = tk.Tk()
    root.title("Password Strength Analyzer & Wordlist Generator")
    root.geometry("400x400")

    notebook = ttk.Notebook(root)
    notebook.pack(fill='both', expand=True)

    # Analyze Tab
    analyze_frame = ttk.Frame(notebook)
    notebook.add(analyze_frame, text="Analyze Password")

    tk.Label(analyze_frame, text="Enter Password:").pack(pady=5)
    entry_password = tk.Entry(analyze_frame, show="*")
    entry_password.pack(pady=5)

    def gui_analyze():
        password = entry_password.get()
        if not password:
            messagebox.showerror("Error", "Please enter a password.")
            return
        result = analyze_password(password)
        messagebox.showinfo("Analysis Result",
                            f"Score: {result['score']}/4\nCrack Time: {result['crack_time']}\nSuggestions: {', '.join(result['feedback']) if result['feedback'] else 'None'}")

    tk.Button(analyze_frame, text="Analyze", command=gui_analyze).pack(pady=10)

    # Generate Tab
    generate_frame = ttk.Frame(notebook)
    notebook.add(generate_frame, text="Generate Wordlist")

    tk.Label(generate_frame, text="Name:").pack(pady=2)
    entry_name = tk.Entry(generate_frame)
    entry_name.pack(pady=2)

    tk.Label(generate_frame, text="Date (YYYY-MM-DD):").pack(pady=2)
    entry_date = tk.Entry(generate_frame)
    entry_date.pack(pady=2)

    tk.Label(generate_frame, text="Pet:").pack(pady=2)
    entry_pet = tk.Entry(generate_frame)
    entry_pet.pack(pady=2)

    include_leet = tk.BooleanVar(value=True)
    tk.Checkbutton(generate_frame, text="Include Leetspeak", variable=include_leet).pack(pady=2)

    include_years = tk.BooleanVar(value=True)
    tk.Checkbutton(generate_frame, text="Include Years", variable=include_years).pack(pady=2)

    def gui_generate():
        name = entry_name.get()
        date = entry_date.get()
        pet = entry_pet.get()
        wordlist = generate_wordlist(name, date, pet, include_leet.get(), include_years.get())
        filename = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt")])
        if filename:
            export_wordlist(wordlist, filename)
            messagebox.showinfo("Success", f"Wordlist saved to {filename}")

    tk.Button(generate_frame, text="Generate & Export", command=gui_generate).pack(pady=10)

    root.mainloop()

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        main()
    else:
        launch_gui()
